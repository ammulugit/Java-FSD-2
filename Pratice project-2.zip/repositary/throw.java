
class Throw
{
	public static void main(String[] args)
	{
		System.out.println(1/0);
	}

	public static void main(String[] args)throws InterruptedException
	{
		Thread.sleep(10000);
		System.out.println("Hello");
	}
}
