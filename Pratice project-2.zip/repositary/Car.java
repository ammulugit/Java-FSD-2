
class car {
	
	public String wheelStatus;
	public int noOfWheels;

	
	public car(String wheelStatus, int noOfWheels)
	{
		this.wheelStatus = wheelStatus;
		this.noOfWheels = noOfWheels;
	}

	
	public void applyBrake()
	{
		wheelStatus = "Stop" System.out.println(
			"Stop the car using break");
	}

	
	public String toString()
	{
		return ("No of wheels in car " + noOfWheels + "\n"
				+ "status of the wheels " + wheelStatus);
	}
}


class Honda extends Car {

	
	public Boolean alloyWheel;

	
	public Honda(String wheelStatus, int noOfWheels,
				Boolean alloyWheel)
	{
		
		super(wheelStatus, noOfWheels);
		alloyWheel = alloyWheel;
	}


	public void setAlloyWheel(Boolean alloyWheel)
	{
		alloyWheel = alloyWheel;
	}

	
	@Override public String toString()
	{
		return (super.toString() + "\nCar alloy wheel "
				+ alloyWheel);
	}
}


public class Main {
	public static void main(String args[])
	{

		Honda honda = new Honda(3, 100, 25);
		System.out.println(honda.toString());
	}
}
