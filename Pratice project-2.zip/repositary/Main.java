import java.io.*;
class Main implements Runnable {
	public static void main(String args[])
	{
		// create an object of Runnable target
		Main comment = new Main();

		// pass the runnable reference to Thread
		Thread t = new Thread(comment, "comment");

		// start the thread
		t.start();

		// get the name of the thread
		System.out.println(t.getName());
	}
	@Override public void run()
	{
		System.out.println("welcome");
	}
}
